class WowiPyException(Exception):
    pass
