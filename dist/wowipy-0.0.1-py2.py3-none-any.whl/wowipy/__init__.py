"""
wowipy.

OPENWOWI Wowiport wrapper for ptyhon
"""

__version__ = "0.0.1"
__author__ = 'Sebastian Bauhaus'
__credits__ = 'Sebastian Bauhaus'
